// src/dao/MemberDAO.java
package dao;

import model.Member;
import util.DatabaseConnection;

import javax.swing.*;
import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class MemberDAO {

    // ------------------------------
    // INSERT MEMBER
    // ------------------------------
    public boolean addMember(Member member) {
        String sql = "INSERT INTO member (id, nama, alamat, no_telepon, email, tanggal_daftar, jenis_member, catatan) "
                + "VALUES (?, ?, ?, ?, ?, ?, ?, ?)";

        try (Connection conn = DatabaseConnection.getConnection();
                PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, member.getId());
            pstmt.setString(2, member.getNama());
            pstmt.setString(3, member.getAlamat());
            pstmt.setString(4, member.getNoTelepon());
            pstmt.setString(5, member.getEmail());
            pstmt.setDate(6, Date.valueOf(member.getTanggalDaftar()));
            pstmt.setString(7, member.getJenisMember());
            pstmt.setString(8, member.getCatatan());

            return pstmt.executeUpdate() > 0;

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error Add Member: " + e.getMessage());
            return false;
        }
    }

    // ------------------------------
    // GET SEMUA MEMBER
    // ------------------------------
    public List<Member> getAllMembers() {
        List<Member> members = new ArrayList<>();
        String sql = "SELECT * FROM member ORDER BY nama";

        try (Connection conn = DatabaseConnection.getConnection();
                Statement stmt = conn.createStatement();
                ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {

                Member member = new Member();
                member.setId(rs.getString("id"));
                member.setNama(rs.getString("nama"));
                member.setAlamat(rs.getString("alamat"));
                member.setNoTelepon(rs.getString("no_telepon"));
                member.setEmail(rs.getString("email"));

                Date tgl = rs.getDate("tanggal_daftar");
                if (tgl != null) {
                    member.setTanggalDaftar(tgl.toLocalDate());
                }

                member.setJenisMember(rs.getString("jenis_member"));
                member.setCatatan(rs.getString("catatan"));

                members.add(member);
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error Get Members: " + e.getMessage());
        }
        return members;
    }

    // ------------------------------
    // DELETE MEMBER
    // ------------------------------
    public boolean deleteMember(String id) {
        String sql = "DELETE FROM member WHERE id = ?";

        try (Connection conn = DatabaseConnection.getConnection();
                PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, id);
            return pstmt.executeUpdate() > 0;

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error Delete Member: " + e.getMessage());
            return false;
        }
    }

    // ------------------------------
    // GENERATE ID (MEM001)
    // ------------------------------
    public String generateId() {
        String sql = "SELECT MAX(id) AS max_id FROM member";

        try (Connection conn = DatabaseConnection.getConnection();
                Statement stmt = conn.createStatement();
                ResultSet rs = stmt.executeQuery(sql)) {

            if (rs.next()) {
                String maxId = rs.getString("max_id");

                if (maxId != null && maxId.length() >= 6) {
                    int num = Integer.parseInt(maxId.substring(3)) + 1;
                    return String.format("MEM%03d", num);
                }
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error Generate ID: " + e.getMessage());
        }

        return "MEM001";
    }

    // ------------------------------
    // SAMPLE DATA
    // ------------------------------
    public void insertSampleData() {

        String[][] sampleData = {
                { "MEM001", "Andi Wijaya", "Jl. Merdeka No. 10", "081234567890", "andi@email.com", "2024-01-01",
                        "Premium" },
                { "MEM002", "Budi Santoso", "Jl. Sudirman No. 5", "081298765432", "budi@email.com", "2024-01-02",
                        "Gold" },
                { "MEM003", "Citra Lestari", "Jl. Thamrin No. 15", "081312345678", "citra@email.com", "2024-01-03",
                        "Silver" },
                { "MEM004", "Dewi Anggraini", "Jl. Gatot Subroto No. 20", "081345678901", "dewi@email.com",
                        "2024-01-04", "Premium" },
                { "MEM005", "Eko Prasetyo", "Jl. Asia Afrika No. 8", "081356789012", "eko@email.com", "2024-01-05",
                        "Gold" }
        };

        String sql = """
                INSERT INTO member (id, nama, alamat, no_telepon, email, tanggal_daftar, jenis_member)
                VALUES (?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT (id) DO NOTHING
                """;

        try (Connection conn = DatabaseConnection.getConnection();
                PreparedStatement pstmt = conn.prepareStatement(sql)) {

            for (String[] data : sampleData) {
                pstmt.setString(1, data[0]);
                pstmt.setString(2, data[1]);
                pstmt.setString(3, data[2]);
                pstmt.setString(4, data[3]);
                pstmt.setString(5, data[4]);
                pstmt.setDate(6, Date.valueOf(data[5]));
                pstmt.setString(7, data[6]);
                pstmt.addBatch();
            }

            pstmt.executeBatch();
            JOptionPane.showMessageDialog(null, "5 sample data member telah ditambahkan!");

        } catch (SQLException e) {
            // Bila duplikat, abaikan
        }
    }
}