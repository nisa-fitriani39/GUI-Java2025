// src/model/Member.java
package model;

import java.time.LocalDate;

/**
 * Model class untuk data Member Gym.
 */
public class Member {

    private String id;
    private String nama;
    private String alamat;
    private String noTelepon;
    private String email;
    private LocalDate tanggalDaftar;
    private String jenisMember;
    private String catatan; // <-- DITAMBAHKAN (sebelumnya hilang)

    // Constructor kosong
    public Member() {
    }

    // Constructor lengkap
    public Member(String id, String nama, String alamat, String noTelepon,
            String email, LocalDate tanggalDaftar, String jenisMember, String catatan) {

        this.id = id;
        this.nama = nama;
        this.alamat = alamat;
        this.noTelepon = noTelepon;
        this.email = email;
        this.tanggalDaftar = tanggalDaftar;
        this.jenisMember = jenisMember;
        this.catatan = catatan;
    }

    // Getter & Setter
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getNama() {
        return nama;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public String getAlamat() {
        return alamat;
    }

    public void setAlamat(String alamat) {
        this.alamat = alamat;
    }

    public String getNoTelepon() {
        return noTelepon;
    }

    public void setNoTelepon(String noTelepon) {
        this.noTelepon = noTelepon;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public LocalDate getTanggalDaftar() {
        return tanggalDaftar;
    }

    public void setTanggalDaftar(LocalDate tanggalDaftar) {
        this.tanggalDaftar = tanggalDaftar;
    }

    public String getJenisMember() {
        return jenisMember;
    }

    public void setJenisMember(String jenisMember) {
        this.jenisMember = jenisMember;
    }

    public String getCatatan() {
        return catatan;
    }

    public void setCatatan(String catatan) {
        this.catatan = catatan;
    }
}
